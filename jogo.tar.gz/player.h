#ifndef PLAYER_H
#define PLAYER_H

#include <allegro5/bitmap.h>
#include <allegro5/color.h>
#include <allegro5/allegro.h>
#include <stdbool.h>
#include "math2d.h"
#include "timer.h"
#include "map.h"
#include "entity.h"

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
//                  VARIAVEIS DO PLAYER SEGUNDO DEFINES
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&

#define MAP_TILE_SIZE 48
#define PLAYER_IDLE_FRICTION .0005f // em um segundo reduz a velocidade a .5% da original
#define PLAYER_RUN_FRICTION .0005f
#define PLAYER_AIR_FRICTION .0005f
#define PLAYER_JUMP_HEIGHT MAP_TILE_SIZE * 3.0
#define PLAYER_GRAVITY MAP_TILE_SIZE * 40
#define PLAYER_TERMINAL_VELOCITY MAP_TILE_SIZE * 20
#define PLAYER_RUN_SPEED MAP_TILE_SIZE * 4
#define PLAYER_AIR_SPEED MAP_TILE_SIZE * 5
#define PLAYER_RUN_ACCEL PLAYER_RUN_SPEED * 5 // MAX SPEED EM 0.25s
#define PLAYER_AIR_ACCEL PLAYER_AIR_SPEED * 5
#define PLAYER_DASH_DURATION 0.2f
#define PLAYER_DASH_LENGTH MAP_TILE_SIZE * 3
#define PLAYER_DASH_SPEED PLAYER_DASH_LENGTH / PLAYER_DASH_DURATION
#define PLAYER_CROUCH_HEIGHT MAP_TILE_SIZE * .75f
#define PLAYER_STAND_HEIGHT MAP_TILE_SIZE * 1.25f
#define ENTITY_ROTATION_SPEED 10

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
//            LOGICA DO PLAYER E INPUT HANDLING PRINCIPAL
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&

// Enums de key_state
enum PLAYER_key_state {
  KEY_UP = 0,
  KEY_PRESSED,
  KEY_HELD,
  KEY_RELEASED,
};

struct PLAYER_input {
  int up;
  int left;
  int down;
  int right;
  int jump;
  int dash;
  int crouch;
};

struct PLAYER_flags {
  bool wants_to_jump;
  bool can_jump;
  bool wants_to_dash;
  bool can_dash;
  bool goes_left;
  bool goes_right;
  bool on_ground;
  bool is_crouching;
};

struct PLAYER_timers {
  struct TIMER_timer dash;
};

enum PLAYER_state {
  PLAYER_STATE_IDLE,
  PLAYER_STATE_SLIDING,
  PLAYER_STATE_RUNNING,
  PLAYER_STATE_JUMPING,
  PLAYER_STATE_FALLING,
  PLAYER_STATE_DASHING,
};

struct PLAYER_player {
  struct ENTITY_entity entity;
  enum PLAYER_key_state keyboard[ALLEGRO_KEY_MAX];
  struct PLAYER_input input;
  enum PLAYER_state state;
  struct PLAYER_flags flags;
  struct MATH2D_vec2 top_left;
  float width, height;
  struct MATH2D_vec2 velocity;
  struct PLAYER_timers timers;
  ALLEGRO_COLOR color;
  float health;
  int max_jumps;
  int jumps_left;
};

// FUNCOES

// estado inicial do player
void PLAYER_init(struct PLAYER_player* player);

// reseta o player a um estado padrao
void PLAYER_reset(struct PLAYER_player* player, struct MATH2D_vec2 start_pos);

// Atualiza o state do player de acordo com o input
void PLAYER_handle_input(enum PLAYER_key_state* keyboard, struct PLAYER_input input, struct PLAYER_flags* flags);

// Atualiza o estado do player de acordo com o ambiente e flags
void PLAYER_update_state(struct PLAYER_flags* flags, enum PLAYER_state* state, struct PLAYER_player* player,
                         float delta_time);

// Handling do movimento do player
void PLAYER_update_movement(struct PLAYER_player* player, float delta_time);

// Consegue o tile em que o player esta
struct MAP_tile* PLAYER_get_tile(struct MAP_map map, struct PLAYER_player player);

// Consegue um array de tiles em volta do player
struct MAP_tile** PLAYER_get_tiles_around(struct MAP_map map, struct PLAYER_player player, int* out_count);

// Modifica o player para resolver a colisao com o tile
void PLAYER_handle_collision(struct PLAYER_player* player, struct MAP_tile* tile);

#endif // !PLAYER_H
