#ifndef TIMER_H
#define TIMER_H

struct TIMER_timer {
  float current;
  float max;
};

// Da tick em um timer
void TIMER_update(struct TIMER_timer* timer, float delta_time);

#endif // !TIMER_H
