#include "math2d.h"

// Checks if player collides with a tile
bool check_aabb_collision(struct MATH2D_vec2 player_pos, float player_w, float player_h, struct MATH2D_vec2 tile_pos,
                          float tile_w, float tile_h) {
  return player_pos.x < tile_pos.x + tile_w && player_pos.x + player_w > tile_pos.x &&
         player_pos.y < tile_pos.y + tile_h && player_pos.y + player_h > tile_pos.y;
}
