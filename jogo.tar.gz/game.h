#ifndef GAME_H
#define GAME_H

#include <allegro5/bitmap.h>
#include <allegro5/keycodes.h>
#include <allegro5/allegro5.h>
#include <allegro5/display.h>
#include <allegro5/events.h>
#include <allegro5/timer.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_image.h>
#include "timer.h"
#include "player.h"
#include "entity.h"
#include "map.h"
#include "math2d.h"

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
// DEFINES UTILIZADAS DURANTE O MAIN DO GAME E NA CONSTRUCAO DO AMBIENTE
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&%

#define GAME_WINDOW_WIDTH 1280
#define GAME_WINDOW_HEIGHT 768
#define GAME_FPS 1 / 30.0

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
// STRUCTS UTILIZADAS DURANTE O MAIN DO GAME E NA CONSTRUCAO DO AMBIENTE
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&%

// Enums do game_state
enum GAME_state {
  GAME_STATE_PLAYING,
  GAME_STATE_MENU,
  GAME_STATE_QUIT,
  GAME_STATE_OVER,
};

struct GAME_time {
  float delta_time, last_time;
};

struct GAME_assets {
  ALLEGRO_BITMAP* wall;
  ALLEGRO_BITMAP* spike;
  ALLEGRO_BITMAP* player_idle;
  ALLEGRO_BITMAP* player_moving;
  ALLEGRO_BITMAP* player_crouching;
  ALLEGRO_BITMAP* player_jumping;
  ALLEGRO_BITMAP* player_dashing;
  ALLEGRO_BITMAP* lava;
  ALLEGRO_BITMAP* cactus;
  ALLEGRO_BITMAP* fire;
  ALLEGRO_BITMAP* enemy;
  ALLEGRO_BITMAP* projectile;
  ALLEGRO_BITMAP* wave;
  ALLEGRO_BITMAP* bird;
};

// Struct para holding de variables utilizadas no ambiente
struct GAME_context {
  struct GAME_assets assets;
  enum GAME_state state;
  ALLEGRO_EVENT event;
  struct GAME_time time;
  ALLEGRO_MOUSE_STATE mouse;
  struct MATH2D_vec2 mouse_pos;
  struct PLAYER_player player;
  struct MAP_map map;
  int level;
  struct MATH2D_vec2 camera_pos;
  struct MATH2D_vec2 render_offset;
  bool game_over;
  bool has_won;
  ALLEGRO_FONT* font;
  struct ENTITY_entities entities;
};

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
// FUNCOES UTILIZADAS DURANTE O MAIN DO GAME E NA CONSTRUCAO DO AMBIENTE
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&%

// Inicializacao do ambiente allegro com installs e init
void GAME_al_init();

// Cria e inicializa um struct struct GAME_context para utilizar em todas as outras libs
struct GAME_context* GAME_init_context();

// Altera as variaveis do contexto para event polling between fps
void GAME_event_poll(struct GAME_context* context);

// Funcao principal de update umbrella
void GAME_update(struct GAME_context* context);

// Funcao principal de render umbrella
void GAME_render(struct GAME_context* context);

// Funcao auxiliar de render para debug (hitbox e vetores)
void GAME_render_debug(struct GAME_context* context);

// Modifica o keystate de acordo com o estado atual no loop
void GAME_update_keystate(struct GAME_context* context);

// Atualiza o delta time
void GAME_update_time(struct GAME_time* time);

void PLAYER_render(struct GAME_context context);

// ENTIDADEoS

bool ENTITY_PLAYER_collision(struct ENTITY_entity* entity, struct PLAYER_player* player);

#endif // !GAME_H
