#include "game.h"
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/bitmap_draw.h>
#include <allegro5/color.h>
#include <allegro5/drawing.h>
#include <allegro5/events.h>
#include <allegro5/keycodes.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "map.h"
#include "player.h"

// Inicializacao do ambiente allegro com installs e init
void GAME_al_init() {
  // o classico do main
  al_init();
  // inits e installs
  al_init_primitives_addon();
  al_init_font_addon();
  al_install_keyboard();
  al_install_mouse();
  al_init_image_addon();
}

// Cria e inicializa um struct struct GAME_context para utilizar em todas as outras libs
struct GAME_context* GAME_init_context() {
  // Malloc inicial
  struct GAME_context* context = malloc(sizeof(struct GAME_context));
  // Inicializacao do ambiente
  // Game state
  context->state = GAME_STATE_MENU;
  // Keyboard state
  memset(context->player.keyboard, 0, sizeof(context->player.keyboard));
  // map init
  MAP_init(&context->map);
  // Player init
  PLAYER_init(&context->player);
  context->level = 1;
  // INIT DE ASSETS
  context->assets.wall = al_load_bitmap("./assets/Wall.png");
  context->assets.spike = al_load_bitmap("./assets/Spike.png");
  context->assets.player_idle = al_load_bitmap("./assets/Player_Idle.png");
  context->assets.player_moving = al_load_bitmap("./assets/Player_Moving_Right.png");
  context->assets.player_crouching = al_load_bitmap("./assets/Player_Moving_Crouch.png");
  context->assets.player_jumping = al_load_bitmap("./assets/Player_Jumping.png");
  context->assets.player_dashing = al_load_bitmap("./assets/Player_Dashing.png");
  context->assets.lava = al_load_bitmap("./assets/Lava.png");
  context->assets.cactus = al_load_bitmap("./assets/Cactus.png");
  context->assets.fire = al_load_bitmap("./assets/Fire.png");
  context->assets.enemy = al_load_bitmap("./assets/Enemy.png");
  context->assets.wave = al_load_bitmap("./assets/Wave.png");
  context->assets.bird = al_load_bitmap("./assets/Bird.png");
  // Initial render offset
  context->render_offset = (struct MATH2D_vec2){(GAME_WINDOW_WIDTH / 2.0f) - (context->player.width / 2.0f),
                                                (GAME_WINDOW_HEIGHT / 2.0f) - (context->player.height / 2.0f)};
  context->camera_pos = (struct MATH2D_vec2){0, 0};
  // other
  context->game_over = false;
  context->has_won = false;
  context->font = al_create_builtin_font();
  // entities
  context->entities.entities = NULL;
  context->entities.count = 0;
  return context;
}

// Altera as variaveis do contexto para event polling between fps
void GAME_event_poll(struct GAME_context* context) {
  // Consegue o evento
  ALLEGRO_EVENT event = context->event;

  // close event
  if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE || ((context->player.keyboard[ALLEGRO_KEY_ESCAPE] == KEY_PRESSED ||
                                                     context->player.keyboard[ALLEGRO_KEY_ESCAPE] == KEY_HELD) &&
                                                    context->state == GAME_STATE_MENU)) {
    context->state = GAME_STATE_QUIT;
    return;
  }
  // to menu event
  if ((context->player.keyboard[ALLEGRO_KEY_BACKSPACE] == KEY_PRESSED ||
       context->player.keyboard[ALLEGRO_KEY_BACKSPACE] == KEY_HELD) &&
      context->state == GAME_STATE_PLAYING) {
    context->state = GAME_STATE_MENU;
    PLAYER_reset(&context->player, context->map.player_start);
    return;
  }

  // key up event
  if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
    if (!context->player.keyboard[event.keyboard.keycode])
      context->player.keyboard[event.keyboard.keycode] = KEY_PRESSED;
    else
      context->player.keyboard[event.keyboard.keycode] = KEY_HELD;
    // key down event
  } else if (event.type == ALLEGRO_EVENT_KEY_UP) {
    context->player.keyboard[event.keyboard.keycode] = KEY_RELEASED;
  }

  // mouse event
  if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
    int mouse_x = event.mouse.x;
    int mouse_y = event.mouse.y;
    int tx = ((mouse_x - context->render_offset.x + context->camera_pos.x) / MAP_TILE_SIZE);
    int ty = ((mouse_y - context->render_offset.y + context->camera_pos.y) / MAP_TILE_SIZE);
    printf("Mouse clicked at tile (%d, %d)\n", tx, ty);
    printf("Map size is (%d, %d)\n", context->map.xsize, context->map.ysize);
    static char tile_types[] = {'a', 'w', 's', 'l', 'c', 'f', 'g'};
    static char entity_types[] = {'b', 'w', 'B', 'W'};
    static char current_type = 'b';
    static int current_index = 0;
    if (tx >= 0 && tx < context->map.xsize && ty >= 0 && ty < context->map.ysize) {
      if (context->player.keyboard[ALLEGRO_KEY_LCTRL] == KEY_PRESSED ||
          context->player.keyboard[ALLEGRO_KEY_LCTRL] == KEY_HELD) {
        // Spawn entidade
        // Muda o tipo de entidade
        if (context->player.keyboard[ALLEGRO_KEY_LSHIFT] == KEY_PRESSED ||
            context->player.keyboard[ALLEGRO_KEY_LSHIFT] == KEY_HELD) {
          if (event.mouse.button == 1)
            current_index--;
          else if (event.mouse.button == 2)
            current_index++;
          current_index = current_index % sizeof(entity_types);
          current_type = entity_types[current_index];
          return;
        }
        printf("Spawning entity of type %c at tile (%d, %d)\n", current_type, tx, ty);
        ENTITY_spawn(&context->entities, (struct MATH2D_vec2){tx * MAP_TILE_SIZE, ty * MAP_TILE_SIZE}, current_type);
        return;
      } else
        // Circula os tiles
        if (event.mouse.button == 3) // left click
        {
          context->map.tiles[tx + ty * context->map.xsize].has_collision =
              !context->map.tiles[tx + ty * context->map.xsize].has_collision;
        } else if (event.mouse.button == 2) { // right click
          context->map.tiles[tx + ty * context->map.xsize].type = 'a';
          context->map.tiles[tx + ty * context->map.xsize].has_collision = false;
        } else if (event.mouse.button == 1) { // middle click cycles through tile types
          char current_type = context->map.tiles[tx + ty * context->map.xsize].type;
          int index = 0;
          for (int i = 0; i < sizeof(tile_types); ++i) {
            if (tile_types[i] == current_type) {
              index = i;
              break;
            }
          }
          index = (index + 1) % sizeof(tile_types);
          context->map.tiles[tx + ty * context->map.xsize].type = tile_types[index];
          context->map.tiles[tx + ty * context->map.xsize].has_collision = true;
        }
    }
  }
}

// Funcao principal de update umbrella
void GAME_update(struct GAME_context* context) {
  // Atualiza o delta_time
  GAME_update_time(&context->time);
  // Menu state
  if (context->state == GAME_STATE_MENU) {
    // Start game se enter
    if (context->player.keyboard[ALLEGRO_KEY_ENTER] == KEY_PRESSED) {
      context->state = GAME_STATE_PLAYING;
      printf("Iniciando o jogo...\n");
      char filename[20];
      sprintf(filename, "map%d.txt", context->level);
      MAP_load(&context->map, filename);
      char entity_filename[25];
      sprintf(entity_filename, "entities_level%d.txt", context->level);
      ENTITY_load_state(&context->entities, entity_filename);
      PLAYER_reset(&context->player, context->map.player_start);
    }
    if (context->player.keyboard[ALLEGRO_KEY_A] == KEY_PRESSED) {
      context->level = fmax(1, context->level - 1);
    } else if (context->player.keyboard[ALLEGRO_KEY_D] == KEY_PRESSED) {
      context->level = fmin(5, context->level + 1);
    }
  }

  // Jogo em si
  else if (context->state == GAME_STATE_PLAYING) {
    context->game_over = false;
    context->has_won = false;
    // Handling do player
    PLAYER_handle_input(context->player.keyboard, context->player.input, &context->player.flags);
    PLAYER_update_state(&context->player.flags, &context->player.state, &context->player, context->time.delta_time);
    PLAYER_update_movement(&context->player, context->time.delta_time);

    // Checa colisao do player com tiles
    struct PLAYER_player* player = &context->player;
    // Consegue os tiles envolta do player
    int count = 0;
    struct MAP_tile** tiles_around = PLAYER_get_tiles_around(context->map, *player, &count);
    // Testa em volta
    for (int t = 0; t < count; ++t) {
      struct MAP_tile* tile = tiles_around[t];
      if (tile->has_collision &&
          check_aabb_collision(player->top_left, player->width, player->height,
                               (struct MATH2D_vec2){tile->coords.x * tile->width, tile->coords.y * tile->height},
                               tile->width, tile->height)) {
        PLAYER_handle_collision(player, tile);
        // Lida com diferentes tiles
        if (tile->type == 's') {
          player->health -= 5.0f;
        } else if (tile->type == 'l') {
          player->health -= 100.0f;
        } else if (tile->type == 'w') {
          // Se colidiu de cima
          if (player->top_left.y + player->height - player->velocity.y * context->time.delta_time <=
              tile->coords.y * tile->height) {
            player->flags.on_ground = true;
            player->velocity.y = 0.0f;
          }
        } else if (tile->type == 'c') {
          player->health -= .2f;
        } else if (tile->type == 'g') {
          printf("Nivel completo!\n");
          context->state = GAME_STATE_MENU;
          context->has_won = true;
          PLAYER_reset(player, context->map.player_start);
        }
      }
    }

    struct MAP_tile* player_tile = PLAYER_get_tile(context->map, context->player);
    if (player_tile != NULL) {
      if (player_tile->type == 'f') { player->health -= 0.75f; }
    }

    if (player->health <= 0.0f || player->top_left.x < 0.0f || player->top_left.y < 0.0f || player->top_left.x > context->map.xsize * MAP_TILE_SIZE || player->top_left.y > context->map.ysize * MAP_TILE_SIZE) {
      printf("Player morreu!\n");
      // respawn e menu
      context->state = GAME_STATE_MENU;
      context->game_over = true;
      PLAYER_reset(player, context->map.player_start);
    }

    // Atualiza as entidades
    ENTITY_update(&context->entities, context->map, context->time.delta_time);

    if (player->state != PLAYER_STATE_DASHING) {
      // Verifica colisao do player com entidades
      for (int e = 0; e < context->entities.count; ++e) {
        struct ENTITY_entity* entity = &context->entities.entities[e];
        if (ENTITY_PLAYER_collision(entity, player)) {
          // Lida com diferentes tipos de entidade
          if (entity->type == 'w') {
            player->health -= 5.0f;
            player->velocity.x += entity->velocity.x * 2;
            ENTITY_destroy(&context->entities, e);
            e--;
          }
          if (entity->type == 'b') {
            player->health -= 1.0f;
            player->velocity.x += entity->velocity.x * 2;
            ENTITY_destroy(&context->entities, e);
            e--;
          }
        }
      }
    }

    // Salva o mapa se f5
    if (context->player.keyboard[ALLEGRO_KEY_F5] == KEY_PRESSED) {
      context->map.player_start = context->player.top_left;
      MAP_save(context->map, "map.txt");
      ENTITY_save_state(context->entities, "entities.txt");
      printf("Mapa salvo em map.txt\n");
    }

    // Carrega o mapa se f6
    if (context->player.keyboard[ALLEGRO_KEY_F6] == KEY_PRESSED) {
      MAP_load(&context->map, "map.txt");
      ENTITY_load_state(&context->entities, "entities.txt");
      PLAYER_reset(&context->player, context->map.player_start);
      printf("Mapa carregado de map.txt\n");
    }
  }

  // Atualiza os keystates para o proximo tick
  GAME_update_keystate(context);
}

// Funcao principal de render umbrella
void GAME_render(struct GAME_context* context) {
  // Bakcground
  al_clear_to_color(al_map_rgb(81, 56, 64));

  // render do menu
  if (context->state == GAME_STATE_MENU) {
    // Renderiza a tela de menu
    al_draw_textf(context->font, al_map_rgb(255, 255, 255), GAME_WINDOW_WIDTH / 2.0f, GAME_WINDOW_HEIGHT / 2.0 - 20,
                  ALLEGRO_ALIGN_CENTRE, "Pressione ENTER para iniciar o jogo");
    al_draw_textf(context->font, al_map_rgb(255, 255, 255), GAME_WINDOW_WIDTH / 2.0f, GAME_WINDOW_HEIGHT / 2.0,
                  ALLEGRO_ALIGN_CENTRE, "A e D para escolher o nivel");
    al_draw_textf(context->font, al_map_rgb(255, 255, 255), GAME_WINDOW_WIDTH / 2.0f, GAME_WINDOW_HEIGHT / 2.0 + 20,
                  ALLEGRO_ALIGN_CENTRE, "NIVEL: %d", context->level);

    // game over
    if (context->game_over) {
      al_draw_textf(context->font, al_map_rgb(255, 0, 0), GAME_WINDOW_WIDTH / 2.0f, GAME_WINDOW_HEIGHT / 2.0f - 60,
                    ALLEGRO_ALIGN_CENTRE, "GAME OVER!");
    }
    // win
    if (context->has_won) {
      al_draw_textf(context->font, al_map_rgb(0, 255, 0), GAME_WINDOW_WIDTH / 2.0f, GAME_WINDOW_HEIGHT / 2.0f - 60,
                    ALLEGRO_ALIGN_CENTRE, "VOCE VENCEU!");
    }
    return;
  } else if (context->state == GAME_STATE_PLAYING) {
    // Camera segue o centro do player
    context->camera_pos.x = context->player.top_left.x;
    context->camera_pos.y = context->player.top_left.y;

    // Renderiza o background do map
    al_draw_scaled_bitmap(context->map.background, 0, 0, al_get_bitmap_width(context->map.background),
                          al_get_bitmap_height(context->map.background),
                          -context->camera_pos.x + context->render_offset.x,
                          -context->camera_pos.y + context->render_offset.y, context->map.xsize * MAP_TILE_SIZE,
                          context->map.ysize * MAP_TILE_SIZE, 0);
    // Renderiza os tiles do mapa
    for (int i = 0; i < context->map.xsize; ++i) {
      for (int j = 0; j < context->map.ysize; ++j) {
        struct MAP_tile* tile = &context->map.tiles[i + j * context->map.xsize];
        struct MATH2D_vec2 tile_render_pos = {
            tile->coords.x * MAP_TILE_SIZE - context->camera_pos.x + context->render_offset.x,
            tile->coords.y * MAP_TILE_SIZE - context->camera_pos.y + context->render_offset.y};
        if (tile->type == 'w') {
          al_draw_scaled_bitmap(context->assets.wall, 0, 0, 32, 32, tile_render_pos.x, tile_render_pos.y, MAP_TILE_SIZE,
                                MAP_TILE_SIZE, 0);
        } else if (tile->type == 's') {
          al_draw_scaled_bitmap(context->assets.spike, 0, 0, 32, 32, tile_render_pos.x, tile_render_pos.y,
                                MAP_TILE_SIZE, MAP_TILE_SIZE, 0);
        } else if (tile->type == 'g') {
          al_draw_filled_rectangle(tile_render_pos.x, tile_render_pos.y, tile_render_pos.x + MAP_TILE_SIZE,
                                   tile_render_pos.y + MAP_TILE_SIZE, al_map_rgb(255, 215, 0));
        } else if (tile->type == 'l') {
          al_draw_scaled_bitmap(context->assets.lava, 0, 0, 32, 32, tile_render_pos.x, tile_render_pos.y, MAP_TILE_SIZE,
                                MAP_TILE_SIZE, 0);
        } else if (tile->type == 'c') {
          al_draw_scaled_bitmap(context->assets.cactus, 0, 0, 32, 32, tile_render_pos.x, tile_render_pos.y,
                                MAP_TILE_SIZE, MAP_TILE_SIZE, 0);
        } else if (tile->type == 'f') {
          al_draw_scaled_bitmap(context->assets.fire, 0, 0, 32, 32, tile_render_pos.x, tile_render_pos.y, MAP_TILE_SIZE,
                                MAP_TILE_SIZE, 0);
        }
      }
    }
    // Renderiza as entidades
    for (int e = 0; e < context->entities.count; ++e) {
      struct ENTITY_entity* entity = &context->entities.entities[e];
      struct MATH2D_vec2 entity_render_pos = {entity->top_left.x - context->camera_pos.x + context->render_offset.x,
                                              entity->top_left.y - context->camera_pos.y + context->render_offset.y};
      if (entity->type == 'w' || entity->type == 'W') {
        al_draw_scaled_bitmap(context->assets.wave, 0, 0, 32, 32, entity_render_pos.x, entity_render_pos.y,
                              entity->width, entity->height, 0);
      } else if (entity->type == 'b' || entity->type == 'B') {
        al_draw_scaled_bitmap(context->assets.bird, 0, 0, 32, 32, entity_render_pos.x, entity_render_pos.y,
                              entity->width, entity->height, 0);
      }
    }
    // Renderia o player de acordo com o estado mantendo a camera no centro do player
    PLAYER_render(*context);
    // Renderiza a HUD
    al_draw_textf(context->font, al_map_rgb(255, 255, 255), 10, 10, 0, "Health: %.1f", context->player.health);
  }
}

// Funcao auxiliar de render para debug (hitbox e vetores)
void GAME_render_debug(struct GAME_context* context) {
  // Renderiza o player na tela
  struct PLAYER_player* player = &context->player;
  al_draw_rectangle(player->top_left.x, player->top_left.y, player->top_left.x + player->width,
                    player->top_left.y + player->height, player->color, 2.0);
  // // Renderiza os tiles do tipo 'w'
  // for (int i = 0; i < MAP_TILE_WIDTH; ++i) {
  //   for (int j = 0; j < MAP_TILE_HEIGHT; ++j) {
  //     struct MAP_tile* tile = &context->map.tiles[i][j];
  //     if (tile->type == 'w') {
  //       al_draw_rectangle(tile->coords.x * tile->width, tile->coords.y * tile->height,
  //                         tile->coords.x * tile->width + tile->width, tile->coords.y * tile->height + tile->height,
  //                         al_map_rgb(100, 100, 100), 2.0);
  //     }
  //   }
  // }
  // Renderiza o vetor do player
  struct MATH2D_vec2 center = {player->top_left.x + player->width / 2, player->top_left.y + player->height / 2};
  struct MATH2D_vec2 velocity_end = {center.x + player->velocity.x / 4.0f, center.y + player->velocity.y / 4.0f};
  al_draw_line(center.x, center.y, velocity_end.x, velocity_end.y, al_map_rgb(255, 0, 255), 2.0);
  // Renderiza um quadrado no centro da tela
  al_draw_rectangle(GAME_WINDOW_WIDTH / 2.0f - 5, GAME_WINDOW_HEIGHT / 2.0f - 5, GAME_WINDOW_WIDTH / 2.0f + 5,
                    GAME_WINDOW_HEIGHT / 2.0f + 5, al_map_rgb(0, 255, 255), 2.0);
}

// Da update nos keystates de acordo com o estado atual
void GAME_update_keystate(struct GAME_context* context) {
  // Percorre todas as keys
  for (int i = 0; i < ALLEGRO_KEY_MAX; ++i) {
    // Se esta pressionado vira hold
    if (context->player.keyboard[i] == KEY_PRESSED) context->player.keyboard[i] = KEY_HELD;
    // Se esta released vira up
    else if (context->player.keyboard[i] == KEY_RELEASED)
      context->player.keyboard[i] = KEY_UP;
  }
}

// Atualiza o delta time
void GAME_update_time(struct GAME_time* time) {
  float current_time = al_get_time();
  time->delta_time = GAME_FPS;
  time->last_time = current_time;
}

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
//            FUNCOES DO PLAYER E INPUT HANDLING PRINCIPAL
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&

// %&%&&%&%&%&%&%&%&%&%&%&%&%&%&&%%&%&%&%&%&%&%&%&&%&%&%&%&%&&%&%&%&%&&%&
//                   FUNCOES DA LOGICA DE MAPA
// %&&%&%&%&%&%&%&%&%&&%&%&%&%%&&%&%&%&%&%&%&%&%&&%&%&%&%&%&%&%&%&%&%&%&

// Renderiza o player de acordo com o estado
void PLAYER_render(struct GAME_context context) {
  struct PLAYER_player* player = &context.player;
  ALLEGRO_BITMAP* to_render = context.assets.player_idle;
  int source_w, source_h;
  source_h = 64;
  source_w = 32;
  switch (player->state) {
    case PLAYER_STATE_IDLE:
      to_render = context.assets.player_idle;
      break;
    case PLAYER_STATE_RUNNING:
      to_render = context.assets.player_moving;
      break;
    case PLAYER_STATE_JUMPING:
      to_render = context.assets.player_jumping;
      break;
    case PLAYER_STATE_FALLING:
      to_render = context.assets.player_moving;
      break;
    case PLAYER_STATE_DASHING:
      to_render = context.assets.player_dashing;
      break;
    case PLAYER_STATE_SLIDING:
      to_render = context.assets.player_moving;
      break;
  }
  if (player->flags.is_crouching) {
    to_render = context.assets.player_crouching;
    source_h = 36;
  }
  printf("Player height: %.2f\n", player->height);
  printf("Player width: %.2f\n", player->width);
  printf("Player state: %d\n", player->state);
  if (player->velocity.x > 0)
    // normal
    al_draw_scaled_bitmap(
        to_render, 0, 0, source_w, source_h, player->top_left.x - context.camera_pos.x + context.render_offset.x,
        player->top_left.y - context.camera_pos.y + context.render_offset.y, player->width, player->height, 0);
  else
    // flip horizontal
    al_draw_scaled_bitmap(to_render, 0, 0, source_w, source_h,
                          player->top_left.x - context.camera_pos.x + context.render_offset.x,
                          player->top_left.y - context.camera_pos.y + context.render_offset.y, player->width,
                          player->height, ALLEGRO_FLIP_HORIZONTAL);
}

bool ENTITY_PLAYER_collision(struct ENTITY_entity* entity, struct PLAYER_player* player) {
  if (check_aabb_collision(player->top_left, player->width, player->height, entity->top_left, entity->width,
                           entity->height)) {
    return true;
  }
  return false;
}
