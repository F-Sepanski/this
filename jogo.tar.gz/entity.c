#include "entity.h"
#include <stdio.h>
#include "utils.h"

// Inicializa uma entidade de um tipo dado
struct ENTITY_entity ENTITY_init(char type) {
  struct ENTITY_entity entity;
  entity.type = type;
  entity.top_left = (struct MATH2D_vec2){0, 0};
  entity.velocity = (struct MATH2D_vec2){0, 0};
  entity.width = 48;
  entity.height = 48;
  if (type == 'W') {
    entity.main_timer.max = random_range(2, 4);
    entity.main_timer.current = entity.main_timer.max;
    entity.width = 64;
  } else if (type == 'B') {
    entity.main_timer.max = random_range(3, 5);
    entity.main_timer.current = entity.main_timer.max;
  } else if (type == 'w') {
    entity.acceleration = (struct MATH2D_vec2){random_range(-100, -200), 0};
    entity.velocity = (struct MATH2D_vec2){50.0f, 0};
  } else if (type == 'b') {
    entity.acceleration = (struct MATH2D_vec2){0, random_range(150, 300)};
    entity.velocity = (struct MATH2D_vec2){random_range(-60, -100), random_range(-50, 50)};
  }
  return entity;
}

// Adiciona uma entidade do tipo a um array de entidades
void ENTITY_spawn(struct ENTITY_entities* entities, struct MATH2D_vec2 position, char type) {
  // Cria a entidade de acordo com o tipo
  struct ENTITY_entity entity = ENTITY_init(type);
  entity.top_left = position;

  // Adiciona na lista global de entidadaes
  if (entities == NULL) {
    entities = malloc(sizeof(struct ENTITY_entity));
  } else {
    struct ENTITY_entity* tmp = realloc(entities->entities, sizeof(struct ENTITY_entity) * (entities->count + 1));
    if (tmp) {
      entities->entities = tmp;
    } else {
      return;
    }
  }
  entities->entities[entities->count] = entity;
  entities->count++;
  printf("spawned entity of type %c at position (%f, %f), indexed on array as %d\n", type, position.x, position.y,
         entities->count - 1);
}

// Remove uma entidade do array de entidades dado o index
void ENTITY_destroy(struct ENTITY_entities* entities, int index) {
  if (index < 0 || index >= entities->count) return;
  // Shift entities down
  for (int i = index; i < entities->count - 1; ++i) { entities->entities[i] = entities->entities[i + 1]; }
  entities->count--;
  if (entities->count > 0) {
    struct ENTITY_entity* tmp = realloc(entities->entities, sizeof(struct ENTITY_entity) * entities->count);
    if (tmp)
      entities->entities = tmp;
    else { return; }
  } else {
    free(entities->entities);
    entities->entities = NULL;
  }
}

// Da update em um array de entidades
void ENTITY_update(struct ENTITY_entities* entities, struct MAP_map map, float delta_time) {
  int count = entities->count;
  for (int i = 0; i < count; ++i) {
    struct ENTITY_entity* entity = &entities->entities[i];
    bool collides = true;
    if (!entity) continue;
    // spawner
    if (entity->type == 'W') {
      entity->main_timer.current -= delta_time;
      if (entity->main_timer.current <= 0) {
        entity->main_timer.current = entity->main_timer.max;
        ENTITY_spawn(entities, entity->top_left, 'w');
        collides = false;
      }
      continue;
    }
    if (entity->type == 'B') {
      entity->main_timer.current -= delta_time;
      if (entity->main_timer.current <= 0) {
        entity->main_timer.current = entity->main_timer.max;
        ENTITY_spawn(entities, entity->top_left, 'b');
        collides = false;
      }
      continue;
    }
    if (entity->type == 'w') {
      entity->velocity.x += entity->acceleration.x * delta_time;
    } else if (entity->type == 'b') {
      // Passaro se move para cima e para baixo
      if (fabsf(entity->velocity.y) > fabsf(entity->acceleration.y)) {
        entity->acceleration.y = entity->acceleration.y * -1.0f;
      }
      entity->velocity.y += entity->acceleration.y * delta_time;
      entity->velocity.x += entity->acceleration.x * delta_time;
      collides = false;
    }
    // Atualiza posicao
    entity->top_left.x += entity->velocity.x * delta_time;
    entity->top_left.y += entity->velocity.y * delta_time;
    // Se for maior que o mapa destroi
    if (entity->top_left.y > map.ysize * MAP_TILE_SIZE || entity->top_left.x > map.xsize * MAP_TILE_SIZE ||
        entity->top_left.x + entity->width < 0) {
      // Remove a entidade do vetor
      ENTITY_destroy(entities, i);
      i--;
      count--;
      continue;
    }
    if (collides) {
      // Checa colisao com mapa
      struct MAP_tile* tile = ENTITY_get_tile(*entity, map);
      if (tile->has_collision &&
          check_aabb_collision(entity->top_left, entity->width, entity->height,
                               (struct MATH2D_vec2){tile->coords.x * tile->width, tile->coords.y * tile->height},
                               tile->width, tile->height)) {
        // Simplesmente reseta a posicao para cima do tile
        entity->top_left.y -= (entity->velocity.y * delta_time);
        entity->velocity.y = 0.0f;
      }
    }
  }
}

// Consegue o tile em que a entidade esta
struct MAP_tile* ENTITY_get_tile(struct ENTITY_entity entity, struct MAP_map map) {
  return &map.tiles[((int)(entity.top_left.x + entity.width / 2) / MAP_TILE_SIZE) +
                    ((int)(entity.top_left.y + entity.height / 2) / MAP_TILE_SIZE) * map.xsize];
}

// Consegue os tiles ao redor da entidade
struct MAP_tile** ENTITY_get_tiles_around(struct ENTITY_entity entity, struct MAP_map map, int* out_count) {
  struct MAP_tile** tiles = malloc(sizeof(struct MAP_tile*) * 9);
  for (int dy = -1; dy <= 1; ++dy) {
    for (int dx = -1; dx <= 1; ++dx) {
      int tx = ((int)(entity.top_left.x + entity.width / 2) / MAP_TILE_SIZE) + dx;
      int ty = ((int)(entity.top_left.y + entity.height / 2) / MAP_TILE_SIZE) + dy;
      if (tx >= 0 && tx < map.xsize && ty >= 0 && ty < map.ysize) {
        tiles[*out_count] = &map.tiles[tx + ty * map.xsize];
        (*out_count)++;
      }
    }
  }
  return tiles;
}

// Salva o estado das entidades em um arquivo txt
void ENTITY_save_state(struct ENTITY_entities entities, const char* filename) {
  FILE* file = fopen(filename, "w");
  for (int i = 0; i < entities.count; ++i) {
    struct ENTITY_entity* entity = &entities.entities[i];
    fprintf(file, "%c %f %f\n", entity->type, entity->top_left.x, entity->top_left.y);
  }
}

// Carrega o estado das entidades de um arquivo txt
void ENTITY_load_state(struct ENTITY_entities* entities, const char* filename) {
  FILE* file = fopen(filename, "r");
  if (!file) {
    printf("Erro ao abrir o arquivo de entidades: %s\n", filename);
    return;
  }
  // Limpa entidades atuais
  free(entities->entities);
  entities->entities = NULL;
  entities->count = 0;

  char line[256];
  while (fgets(line, sizeof(line), file)) {
    char type;
    float x, y;
    if (sscanf(line, "%c %f %f", &type, &x, &y) == 3) { ENTITY_spawn(entities, (struct MATH2D_vec2){x, y}, type); }
  }
  fclose(file);
}
