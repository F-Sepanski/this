#ifndef UTILS_H
#define UTILS_H

#include <stdlib.h>

// Cria um numero float aleatorio entre min e max
float random_range(float min, float max);

#endif // !UTILS_H
