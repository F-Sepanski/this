#include "map.h"
#include <stdio.h>
#include <allegro5/allegro.h>

// Inicializa um mapa basico
void MAP_init(struct MAP_map* map) {
  // Inicializa o size
  map->xsize = 32;
  map->ysize = 32;
  // O player start
  map->player_start = (struct MATH2D_vec2){MAP_TILE_SIZE, MAP_TILE_SIZE * (map->ysize - 2)};
  // Bitmap padrao
  map->background = al_load_bitmap("./assets/bg2.jpg");
  // Inicializa os tiles
  struct MAP_tile* map_tiles = malloc(sizeof(struct MAP_tile) * map->xsize * map->ysize);
  map->tiles = map_tiles;
  // Faz uma box around
  for (int i = 0; i < map->xsize; ++i) {
    for (int j = 0; j < map->ysize; ++j) {
      if (j > map->ysize - 2 || j == 0 || i == 0 || i == map->xsize - 1) {
        map_tiles[i + j * map->xsize].type = 'w';
        map_tiles[i + j * map->xsize].has_collision = true;
      } else {
        map_tiles[i + j * map->xsize].type = 'a';
        map_tiles[i + j * map->xsize].has_collision = false;
      }
      map_tiles[i + j * map->xsize].coords = (struct MATH2D_vec2){i, j};
      map_tiles[i + j * map->xsize].width = MAP_TILE_SIZE;
      map_tiles[i + j * map->xsize].height = MAP_TILE_SIZE;
    }
  }
}

// Salva o mapa como um txt
void MAP_save(struct MAP_map map, const char* filename) {
  // Cria
  FILE* file = fopen(filename, "w");
  // Escreve o size
  fprintf(file, "%d %d\n", map.xsize, map.ysize);
  // Escreve o player spawn
  fprintf(file, "%f %f\n", map.player_start.x, map.player_start.y);
  // Escreve a matrix de tiles
  struct MAP_tile* map_tiles = map.tiles;
  for (int y = 0; y < map.ysize; ++y) {
    for (int x = 0; x < map.xsize; ++x) { fprintf(file, "%c", map_tiles[x + y * map.xsize].type); }
    fprintf(file, "\n");
  }
  fclose(file);
}

// Carrega o mapa de um txt
void MAP_load(struct MAP_map* map, const char* filename) {
  // Abre
  FILE* file = fopen(filename, "r");
  if (!file) {
    printf("Erro ao abrir o arquivo de mapa: %s\n", filename);
    return;
  }
  // Le o size
  fscanf(file, "%d %d\n", &map->xsize, &map->ysize);
  // Le o player spawn
  fscanf(file, "%f %f\n", &map->player_start.x, &map->player_start.y);
  // Le os tiles
  // Aloca novo tamanho para os tiles
  if (map->tiles) free(map->tiles);
  map->tiles = malloc(sizeof(struct MAP_tile) * map->xsize * map->ysize);
  // Inicia com ar
  memset(map->tiles, 97, sizeof(struct MAP_tile) * map->xsize * map->ysize);

  // Le a matrix de tiles
  struct MAP_tile* map_tiles = map->tiles;
  char line[map->xsize + 2];
  for (int y = 0; y < map->ysize; ++y) {
    if (!fgets(line, sizeof(line), file)) break;
    for (int x = 0; x < map->xsize; ++x) {
      if (line[x] == '\n' || line[x] == '\0') break;
      int idx = x + y * map->xsize;
      map_tiles[idx].type = line[x];
      map_tiles[idx].has_collision = (map_tiles[idx].type != 'a' && map_tiles[idx].type != 'f');
      map_tiles[idx].coords = (struct MATH2D_vec2){x, y};
      map_tiles[idx].width = MAP_TILE_SIZE;
      map_tiles[idx].height = MAP_TILE_SIZE;
    }
  }
  fclose(file);
}
