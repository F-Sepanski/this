#include "player.h"
#include "math2d.h"
#include "map.h"
#include "timer.h"
#include <allegro5/allegro.h>

// estado inicial do player
void PLAYER_init(struct PLAYER_player* player) {
  player->top_left = (struct MATH2D_vec2){0, 0};
  player->height = PLAYER_STAND_HEIGHT;
  player->width = MAP_TILE_SIZE / 1.5f;
  player->velocity = (struct MATH2D_vec2){0, 0};
  player->state = PLAYER_STATE_IDLE;
  player->input.left = ALLEGRO_KEY_A;
  player->input.right = ALLEGRO_KEY_D;
  player->input.jump = ALLEGRO_KEY_SPACE;
  player->input.dash = ALLEGRO_KEY_LSHIFT;
  player->input.crouch = ALLEGRO_KEY_S;
  player->flags.can_jump = true;
  player->flags.can_dash = true;
  player->flags.on_ground = false;
  player->color = al_map_rgb(255, 255, 255);
  player->timers.dash.max = 1.0f;
  player->health = 100.0f;
}

// reseta o player a um estado padrao
void PLAYER_reset(struct PLAYER_player* player, struct MATH2D_vec2 start_pos) {
  player->top_left = (struct MATH2D_vec2){start_pos.x, start_pos.y};
  player->height = PLAYER_STAND_HEIGHT;
  player->width = MAP_TILE_SIZE / 1.5f;
  player->velocity = (struct MATH2D_vec2){0, 0};
  player->state = PLAYER_STATE_IDLE;
  player->input.left = ALLEGRO_KEY_A;
  player->input.right = ALLEGRO_KEY_D;
  player->input.jump = ALLEGRO_KEY_SPACE;
  player->input.dash = ALLEGRO_KEY_LSHIFT;
  player->input.crouch = ALLEGRO_KEY_S;
  player->flags.can_jump = true;
  player->flags.can_dash = true;
  player->flags.on_ground = false;
  player->color = al_map_rgb(255, 255, 255);
  player->timers.dash.max = 1.0f;
  player->health = 100.0f;
}

// Atualiza as flags do player de acordo com o input
void PLAYER_handle_input(enum PLAYER_key_state* keyboard, struct PLAYER_input input, struct PLAYER_flags* flags) {
  // Reseta flags
  flags->wants_to_jump = false;
  flags->wants_to_dash = false;
  flags->goes_left = false;
  flags->goes_right = false;
  flags->is_crouching = false;

  // Ifs infinitos
  if (keyboard[input.crouch] == KEY_PRESSED || keyboard[input.crouch] == KEY_HELD) flags->is_crouching = true;
  if (keyboard[input.jump] == KEY_PRESSED) flags->wants_to_jump = true;
  if (keyboard[input.dash] == KEY_PRESSED) flags->wants_to_dash = true;
  enum PLAYER_key_state left = keyboard[input.left];
  enum PLAYER_key_state right = keyboard[input.right];
  if ((left == KEY_PRESSED || left == KEY_HELD) && (right == KEY_UP || right == KEY_RELEASED)) flags->goes_left = true;
  if ((right == KEY_PRESSED || right == KEY_HELD) && (left == KEY_UP || left == KEY_RELEASED)) flags->goes_right = true;
}

// Atualiza o estado do player de acordo com o ambiente e flags
void PLAYER_update_state(struct PLAYER_flags* flags, enum PLAYER_state* state, struct PLAYER_player* player,
                         float delta_time) {
  // Da update nos timer
  TIMER_update(&player->timers.dash, delta_time);
  if (player->timers.dash.current == 0) { flags->can_dash = true; }

  // mid dash
  if (*state == PLAYER_STATE_DASHING) {
    // tick do timer de dash
    if (player->timers.dash.current <= player->timers.dash.max - PLAYER_DASH_DURATION) {
      // termina o dash
      *state = PLAYER_STATE_JUMPING;
    }
    return;
  }
  // Modifica para crouch
  if (player->flags.is_crouching) {
    player->height = PLAYER_CROUCH_HEIGHT;
    // Verifica se acabou de clicar
    if (player->keyboard[player->input.crouch] == KEY_PRESSED) { player->flags.on_ground = false; }
  } else {
    player->height = PLAYER_STAND_HEIGHT;
  }

  // entra no dash
  if (flags->wants_to_dash && flags->can_dash) {
    *state = PLAYER_STATE_DASHING;
    // Modifica o timer e o can_dash
    player->timers.dash.current = player->timers.dash.max;
    player->flags.can_dash = false;
    // Aplica o boost de velocidade
    player->velocity.x = (flags->goes_right - flags->goes_left) * PLAYER_DASH_SPEED;
    if (player->velocity.x == 0) {
      // Dash para baixo
      player->velocity.y = PLAYER_DASH_SPEED;
    } else {
      // Ignora queda ou subida
      player->velocity.y = 0;
    }
    player->flags.on_ground = false;
    player->color = al_map_rgb(255, 0, 0);
    return;
  }

  // No chao para pulando
  if (flags->wants_to_jump && flags->on_ground && flags->can_jump) {
    *state = PLAYER_STATE_JUMPING;
    player->velocity.y = -sqrtf(2.0f * PLAYER_GRAVITY * (PLAYER_JUMP_HEIGHT));
    player->flags.on_ground = false;
    player->color = al_map_rgb(0, 255, 0);
    return;
  }

  // Pulando para caindo
  if (!flags->on_ground && player->velocity.y > 0) {
    *state = PLAYER_STATE_FALLING;
    player->color = al_map_rgb(0, 0, 255);
    return;
  }

  // Caindo para pulando
  if (!flags->on_ground && player->velocity.y < 0 && flags->can_jump) {
    *state = PLAYER_STATE_JUMPING;
    player->color = al_map_rgb(0, 255, 0);
    return;
  }

  // Idle para correndo
  if (flags->goes_left || flags->goes_right) {
    *state = PLAYER_STATE_RUNNING;
    if (player->velocity.y > 0) {
      *state = PLAYER_STATE_FALLING;
      flags->on_ground = false;
    }
    player->color = al_map_rgb(255, 255, 0);
    return;
  }

  // Sliding
  if (flags->on_ground && player->velocity.x != 0) {
    *state = PLAYER_STATE_SLIDING;
    player->color = al_map_rgb(150, 150, 150);
    return;
  }

  // Idle
  if (flags->on_ground) {
    *state = PLAYER_STATE_IDLE;
    player->color = al_map_rgb(255, 255, 255);
    return;
  }
}

// Handling do movimento do player
void PLAYER_update_movement(struct PLAYER_player* player, float delta_time) {
  // swicth case do estado
  switch (player->state) {
    case PLAYER_STATE_IDLE:
      // Friccao de idle
      player->velocity.x *= pow(PLAYER_IDLE_FRICTION, delta_time);
      // Gravidade
      player->velocity.y += PLAYER_GRAVITY * delta_time;
      break;
    case PLAYER_STATE_SLIDING:
      // Friccao de idle
      player->velocity.x *= pow(PLAYER_IDLE_FRICTION, delta_time);
      // Gravidade
      player->velocity.y += PLAYER_GRAVITY * delta_time;
      break;
    case PLAYER_STATE_RUNNING:
      // Aceleracao
      if (player->flags.goes_right)
        if (!player->flags.is_crouching)
          player->velocity.x = fmin(player->velocity.x + PLAYER_RUN_ACCEL * delta_time, PLAYER_RUN_SPEED);
        else
          player->velocity.x = (fmin(player->velocity.x + PLAYER_RUN_ACCEL * delta_time, PLAYER_RUN_SPEED)) / 1.2f;
      else if (player->flags.goes_left)
        if (!player->flags.is_crouching)
          player->velocity.x = fmax(player->velocity.x - PLAYER_RUN_ACCEL * delta_time, -PLAYER_RUN_SPEED);
        else
          player->velocity.x = (fmax(player->velocity.x - PLAYER_RUN_ACCEL * delta_time, -PLAYER_RUN_SPEED)) / 1.2f;
      else
        player->velocity.x *= pow(PLAYER_RUN_FRICTION, delta_time);
      // Gravidade
      player->velocity.y += PLAYER_GRAVITY * delta_time;
      break;
    case PLAYER_STATE_JUMPING:
      // Aplica gravidade
      if (player->keyboard[player->input.jump] == KEY_HELD)
        player->velocity.y += PLAYER_GRAVITY * delta_time;
      else
        player->velocity.y += PLAYER_GRAVITY * 2.0f * delta_time;
      // Air control
      if (player->flags.goes_left)
        player->velocity.x = fmax(player->velocity.x - PLAYER_AIR_ACCEL * delta_time, -PLAYER_AIR_SPEED);
      else if (player->flags.goes_right)
        player->velocity.x = fmin(player->velocity.x + PLAYER_AIR_ACCEL * delta_time, PLAYER_AIR_SPEED);
      else
        player->velocity.x *= pow(PLAYER_AIR_FRICTION, delta_time);
      break;
    case PLAYER_STATE_FALLING:
      player->velocity.y = fmin(player->velocity.y + PLAYER_GRAVITY * 1.8f * delta_time, PLAYER_TERMINAL_VELOCITY);
      // Air control
      if (player->flags.goes_left)
        player->velocity.x = fmax(player->velocity.x - PLAYER_AIR_ACCEL * delta_time, -PLAYER_AIR_SPEED);
      else if (player->flags.goes_right)
        player->velocity.x = fmin(player->velocity.x + PLAYER_AIR_ACCEL * delta_time, PLAYER_AIR_SPEED);
      else
        player->velocity.x *= pow(PLAYER_AIR_FRICTION, delta_time);
      break;
    case PLAYER_STATE_DASHING:
      // sai do dash se flag de movimento ser contra a velocidade
      if ((player->velocity.x > 0 && player->flags.goes_left) || (player->velocity.x < 0 && player->flags.goes_right)) {
        player->timers.dash.current = 0;
      }
      break;
  }
  // Clamps para fica menos icy
  if (fabs(player->velocity.x) < 0.5f) player->velocity.x = 0.0f;

  // Atualiza posicao
  player->top_left.x += player->velocity.x * delta_time;
  player->top_left.y += player->velocity.y * delta_time;
}

// consegue o tile em que o player esta
struct MAP_tile* PLAYER_get_tile(struct MAP_map map, struct PLAYER_player player) {
  return &map.tiles[((int)(player.top_left.x + player.width / 2) / MAP_TILE_SIZE) +
                    ((int)(player.top_left.y + player.height / 2) / MAP_TILE_SIZE) * map.xsize];
}

// Consegue um array de tiles em volta do player
struct MAP_tile** PLAYER_get_tiles_around(struct MAP_map map, struct PLAYER_player player, int* out_count) {
  int player_tile_x = (int)(player.top_left.x + player.width / 2) / MAP_TILE_SIZE;
  int player_tile_y = (int)(player.top_left.y + player.height / 2) / MAP_TILE_SIZE;

  struct MAP_tile** tiles = malloc(sizeof(struct MAP_tile*) * 9);
  int count = 0;

  for (int dy = -1; dy <= 1; ++dy) {
    for (int dx = -1; dx <= 1; ++dx) {
      int tx = player_tile_x + dx;
      int ty = player_tile_y + dy;
      if (tx >= 0 && tx < map.xsize && ty >= 0 && ty < map.ysize) { tiles[count++] = &map.tiles[tx + ty * map.xsize]; }
    }
  }
  *out_count = count;
  return tiles;
}

// Resolves collision by moving player out of tile (simple version)
void PLAYER_handle_collision(struct PLAYER_player* player, struct MAP_tile* tile) {
  float px = player->top_left.x, py = player->top_left.y;
  float pw = player->width, ph = player->height;
  float tx = tile->coords.x * tile->width, ty = tile->coords.y * tile->height;
  float tw = tile->width, th = tile->height;

  float overlap_x = fmin(px + pw, tx + tw) - fmax(px, tx);
  float overlap_y = fmin(py + ph, ty + th) - fmax(py, ty);

  if (overlap_x < overlap_y) {
    // Resolve X axis
    if (px < tx)
      player->top_left.x -= overlap_x + 0.1f;
    else
      player->top_left.x += overlap_x + 0.1f;
    player->velocity.x = 0;
  } else {
    // Resolve Y axis
    if (py < ty)
      player->top_left.y -= overlap_y + 0.1f;
    else
      player->top_left.y += overlap_y + 0.1f;
    player->velocity.y = 0;
    player->flags.on_ground = true;
  }
}
