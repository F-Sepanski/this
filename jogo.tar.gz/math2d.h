#ifndef MATH2D_H
#define MATH2D_H

#include <math.h>
#include <stdbool.h>

struct MATH2D_vec2 {
  float x;
  float y;
};

// Checks if player collides with a tile
bool check_aabb_collision(struct MATH2D_vec2 player_pos, float player_w, float player_h, struct MATH2D_vec2 tile_pos,
                          float tile_w, float tile_h);

#endif // !MATH2D_H
