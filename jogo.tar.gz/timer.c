#include "timer.h"

// essa funcao atualiza um timer dado o delta time
void TIMER_update(struct TIMER_timer* timer, float delta_time) {
  if (timer->current <= 0) {
    timer->current = 0;
  } else {
    if (timer->current > timer->max) timer->current = timer->max;
    timer->current -= delta_time;
  }
}
