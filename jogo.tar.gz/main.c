#include <allegro5/events.h>
#include "game.h"

int main(void) {
  // inicializa o environment do allegro5
  GAME_al_init();

  // cria o game context para o ambiente
  struct GAME_context* context = GAME_init_context();

  // inicializacao de outros game systems do allegro5
  ALLEGRO_DISPLAY* display = al_create_display(GAME_WINDOW_WIDTH, GAME_WINDOW_HEIGHT);
  ALLEGRO_TIMER* fps_timer = al_create_timer(GAME_FPS);
  ALLEGRO_EVENT_QUEUE* event_queue = al_create_event_queue();

  // Associacao de eventos com a event_queue
  al_register_event_source(event_queue, al_get_display_event_source(display));
  al_register_event_source(event_queue, al_get_timer_event_source(fps_timer));
  al_register_event_source(event_queue, al_get_keyboard_event_source());
  al_register_event_source(event_queue, al_get_mouse_event_source());

  // Start do game loop
  al_start_timer(fps_timer);
  while (context->state != GAME_STATE_QUIT) {
    // Consegue o evento to update e anexa no context
    while (al_get_next_event(event_queue, &context->event)) {
      // Event polling ate o tick do clock
      GAME_event_poll(context);

      // Clock do fps_timer
      if (context->event.type == ALLEGRO_EVENT_TIMER) {
        GAME_update(context);
        GAME_render(context);
        // GAME_render_debug(context);
        al_flip_display();
      }
      // GAME_STATE_QUIT
      if (context->state == GAME_STATE_QUIT) break;
    }
  }

  // Cleanup
  al_destroy_event_queue(event_queue);
  al_destroy_timer(fps_timer);
  al_destroy_display(display);

  return EXIT_SUCCESS;
}
