#include "utils.h"

// Cria um numero float aleatorio entre min e max
float random_range(float min, float max) { return min + ((float)rand() / (float)RAND_MAX) * (max - min); }
