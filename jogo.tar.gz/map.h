#ifndef MAP_H
#define MAP_H
#include <allegro5/bitmap.h>
#include "math2d.h"

#define MAP_TILE_SIZE 48

struct MAP_tile {
  struct MATH2D_vec2 coords;
  float width, height;
  char type;
  bool has_collision;
};

struct MAP_map {
  struct MAP_tile* tiles;
  ALLEGRO_BITMAP* background;
  int xsize;
  int ysize;
  struct MATH2D_vec2 player_start;
};

// Inicializa um mapa basico
void MAP_init(struct MAP_map* map);

// Salva o mapa como um txt
void MAP_save(struct MAP_map map, const char* filename);

// Carrega o mapa de um txt
void MAP_load(struct MAP_map* map, const char* filename);

#endif // !MAP_H
