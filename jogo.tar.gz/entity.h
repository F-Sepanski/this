#ifndef ENTITY_H
#define ENTITY_H

#define ENTITY_GRAVITY 100
#define ENTITY_WIND_FORCE 100

#include "math2d.h"
#include "timer.h"
#include "map.h"
#include <allegro5/bitmap.h>
#include "utils.h"

// Entidade
struct ENTITY_entity {
  struct MATH2D_vec2 top_left;
  struct MATH2D_vec2 velocity;
  struct MATH2D_vec2 acceleration;
  char type;
  float width, height;
  ALLEGRO_BITMAP* sprite;
  struct TIMER_timer main_timer;
};

// Vetores de entidades
struct ENTITY_entities {
  struct ENTITY_entity* entities;
  int count;
};

// Inicializa uma entidade de um tipo dado
struct ENTITY_entity ENTITY_init(char type);

// Adiciona uma entidade do tipo a um array de entidades
void ENTITY_spawn(struct ENTITY_entities* entities, struct MATH2D_vec2 position, char type);

// Remove uma entidade do array de entidades dado o index
void ENTITY_destroy(struct ENTITY_entities* entities, int index);

// Atualiza um array de entidades no mapa
void ENTITY_update(struct ENTITY_entities* entities, struct MAP_map map, float delta_time);

// Consegue o tile em que a entidade esta
struct MAP_tile* ENTITY_get_tile(struct ENTITY_entity entity, struct MAP_map map);

// Consegue os tiles ao redor da entidade
struct MAP_tile** ENTITY_get_tiles_around(struct ENTITY_entity entity, struct MAP_map map, int* out_count);

// Salva o estado das entidades em um arquivo txt
void ENTITY_save_state(struct ENTITY_entities entities, const char* filename);

// Carrega o estado das entidades de um arquivo txt
void ENTITY_load_state(struct ENTITY_entities* entities, const char* filename);

#endif // !ENTITY_H
